![image](https://github.com/2020-Robotics-Aerial-Robots/Homework/blob/main/hw1/LOGO%20%E4%B8%AD%E8%8B%B1%E6%96%87%E6%A9%AB.png)

# Homework5
---
1. Given a set of 50 input data and output data,please find the ideal linear regression model! (40%)(HW5-1.xls)



2. Given the Inertial frame and body-fixed frame on a UAV with their axes initially aligned, where their z axes are pointing upward (opposite to the direction of the gravity), please find the attitude trajectory of the UAV (i.e., ) given the measurement of the accelerometer of SI unit stored in the excel file. The magnitude of the gravity is 9.8  pointing to -z axis of the inertial frame. (60%)(HW5-2.xls)
